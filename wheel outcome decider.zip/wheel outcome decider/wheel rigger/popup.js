
function saveOutcome() {
    const val = document.getElementById("desired").value;
    console.log("Saved:", val);
    alert("Saved: " + val);
}
